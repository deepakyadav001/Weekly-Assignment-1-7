import random
import json
from datetime import datetime

# Load responses from JSON file
responses = {
    "name": ["The name of the college is The British College"],
    "hi": ["Hello, {name}! How can I help you?", "Welcome, {name}! How may I assist you?"],
    "principal": ["The name of our Principal is Dr. Patrick M."],
    "admission": ["Admissions will start from the second week of September. For more details, contact us or visit our website www.www.com"],
    "location": ["Our college is located in Thapathali, Kathmandu, Nepal."],
    "facilities": ["We have facilities like sports, a cafe, a library, a VR room, and more."],
    "coffee": ["The campus coffee bar is open from 8 AM to 8 PM daily."],
    "disconnect": ["Oh no, it seems like we've been disconnected! Please refresh to reconnect."],
    "noreply": ["Sorry, I am not trained to answer that.", "I don't have an answer for that yet."],
}

# Save responses to a JSON file for flexibility
with open("responses.json", "w") as f:
    json.dump(responses, f, indent=4)

# Load responses from the JSON file
def load_responses():
    with open("responses.json", "r") as f:
        return json.load(f)

def log_conversation(user_name, user_input, response):
    with open("chat_log.txt", "a") as log_file:
        log_file.write(f"[{datetime.now()}] {user_name}: {user_input}\n")
        log_file.write(f"[{datetime.now()}] Agent: {response}\n")

# Randomly generated agent names
agent_names = ["Alex", "John", "Jimmy", "Ryan", "Denis", "Roger"]

# Greeting and setup
user_name = input("Enter your name: ")
print(f"Welcome, {user_name}, to the Chatbot! You can ask anything about our college.")
agent_name = random.choice(agent_names)
print(f"Hello, I am your agent {agent_name}.")

responses = load_responses()

while True:
    user_input = input("Ask a question (or type 'bye' to exit): ").lower()
    if user_input in ["bye", "quit", "exit"]:
        print("Bye! It was nice talking with you.")
        break

    # Simulate random disconnection
    if random.randint(1, 50) == 25:
        print(random.choice(responses["disconnect"]))
        break

    # Check for keywords
    keywords = set(user_input.split())
    matched = False
    for key, reply_list in responses.items():
        if key in keywords:
            response = random.choice(reply_list).format(name=user_name)
            print(response)
            log_conversation(user_name, user_input, response)
            matched = True
            break

    if not matched:
        response = random.choice(responses["noreply"])
        print(response)
        log_conversation(user_name, user_input, response)