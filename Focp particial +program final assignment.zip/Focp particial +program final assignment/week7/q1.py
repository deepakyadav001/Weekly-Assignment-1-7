def union_of_letters(word1,word2):
    return sorted(set(word1)|set(word2))
def common_letters(word1,word2):
    return sorted(set(word1)&set(word2)) 
def unique_to_each_word(word1,word2):
    return sorted(set(word1)^set(word2))
word1 = input("Enter the first word: ")
word2 = input("Enter the second word: ")

print(f"Letters in either word: {union_of_letters(word1, word2)}")
print(f"Letters in both words: {common_letters(word1, word2)}")
print(f"Letters in one but not both: {union_of_letters(word1, word2)}")
