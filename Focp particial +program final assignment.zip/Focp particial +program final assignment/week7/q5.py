from collections import Counter

def process_message_and_report(message):
    """
    Processes a message to find the six most common letters, ignoring case,
    and reports their frequencies.
    """
    # Initialize a dictionary with zero counts for each letter
    letter_counts = {chr(letter): 0 for letter in range(ord('a'), ord('z') + 1)}

    # Count each letter in the message, ignoring case
    for char in message.lower():
        if char.isalpha():
            letter_counts[char] += 1

    # Convert the dictionary into a Counter object for sorting
    counts = Counter(letter_counts)

    # Get the six most common letters and their counts
    most_common = counts.most_common(6)

    # Print the results
    print("The six most common letters are:")
    for letter, count in most_common:
        print(f"{letter}: {count}")

# Example usage
if __name__ == "__main__":
    user_message = input("Enter a message: ")
    process_message_and_report(user_message)
