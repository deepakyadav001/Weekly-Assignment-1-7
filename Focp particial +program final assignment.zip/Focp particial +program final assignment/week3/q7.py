# propt the user to enter a number  for the times table
number = int(input("Enter a num between o and 12 to display its times table: "))

#chech if the  number is within the valid range
if -0 <= number <= 12:
    # loop through number 0 to 12
        for i in range(13):
            print(f"{i} x{number} = {i * number}")
else:
    print("Error: please enter a number between 0 and  12.")
            
