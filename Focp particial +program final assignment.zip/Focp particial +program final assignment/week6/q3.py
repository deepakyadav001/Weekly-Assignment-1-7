def is_prime(number):
    """
    Determines if a given integer is a prime number.
   
    :param number: An integer to check for primality
    :return: True if the number is prime, False otherwise
    """
    if number <= 1:
        return False  # Prime numbers are greater than 1
    for i in range(2, int(number ** 0.5) + 1):
        if number % i == 0:
            return False  # Divisible by another number, not prime
    return True

# Test the function
def test_is_prime():
    test_numbers = [2, 3, 4, 5, 10, 17, 19, 20, 23, 25, -5, 0, 1]
    for num in test_numbers:
        print(f"Is {num} a prime number? {is_prime(num)}")

# Run the tests
test_is_prime()
