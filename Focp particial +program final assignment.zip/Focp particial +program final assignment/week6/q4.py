def encrypt_message(message):
    
    # Remove spaces from the message
    no_space_message = message.replace(" ", "")
    # Reverse the resulting string
    encrypted_message = no_space_message[::-1]
    return encrypted_message

# Test the function
def test_encrypt_message():
    test_messages = [
        "Hello World",
        "Python is fun",
        "This is a test message",
        "No spaces here",
        "Encryption is cool"
    ]
    for msg in test_messages:
        print(f"Original: {msg}")
        print(f"Encrypted: {encrypt_message(msg)}\n")

# Run the test
test_encrypt_message()
