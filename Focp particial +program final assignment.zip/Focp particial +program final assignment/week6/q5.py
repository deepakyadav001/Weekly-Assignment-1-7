import random
import string

def decrypt_with_interval(encrypted_message, interval):
    """
    Decrypts a message by removing the random characters inserted at the interval positions.
   
    :param encrypted_message: The encrypted string containing random characters.
    :param interval: The interval at which random characters were inserted.
    :return: The original decrypted message.
    """
    decrypted_message = []
   
    # Iterate through the encrypted message and pick the characters that are part of the original message
    for i, char in enumerate(encrypted_message):
        if char not in string.ascii_lowercase or (i + 1) % interval != 0:
            decrypted_message.append(char)
   
    # Join the decrypted characters into a string and return
    return ''.join(decrypted_message)

# Test the function
def test_decrypt_with_interval():
    encrypted_message = "senx dxx chx eesxex"  # Example encrypted message
    interval_used = 3  # Example interval that was used during encryption
    decrypted_message = decrypt_with_interval(encrypted_message, interval_used)
 print(f"Encrypted Message: {encrypted_message}
    print(f"Decrypted Message: {decrypted_message}")

# Run the test
test_decrypt_with_interval()
