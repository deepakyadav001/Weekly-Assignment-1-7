import sys
import os
from collections import defaultdict
from statistics import mean
from tabulate import tabulate

def read_driver_details(filename="f1_drivers.txt"):
    """Read driver details and store them in a dictionary."""
    driver_details = {}
    try:
        with open(filename, "r") as file:
            for line_number, line in enumerate(file, start=1):
                parts = line.strip().split(",")
                if len(parts) == 4:
                    _, code, name, team = [part.strip() for part in parts]
                    driver_details[code] = {"name": name, "team": team}
                else:
                    print(f"Warning: Skipping malformed line {line_number}: {line.strip()}")
    except FileNotFoundError:
        print(f"Warning: {filename} not found. Proceeding without driver details.")
    return driver_details


def process_lap_times(file_path):
    """Process the lap time data and display various statistics."""
    if not os.path.exists(file_path):
        print(f"Error: File '{file_path}' not found.")
        return

    # Reading the lap times data
    with open(file_path, "r") as file:
        lines = file.readlines()
    
    # Extracting the race location from the first line
    race_location = lines[0].strip()
    lap_times = [line.strip() for line in lines[1:]]

    # Data storage: mapping drivers to their lap times
    driver_lap_times = defaultdict(list)

    for entry in lap_times:
        driver_code = entry[:3]
        lap_time = float(entry[3:])
        driver_lap_times[driver_code].append(lap_time)

    # Load driver details
    driver_details = read_driver_details()

    # Calculate statistics
    fastest_overall = None
    fastest_driver = None
    all_times = []

    driver_stats = []

    for driver, times in driver_lap_times.items():
        fastest_time = min(times)
        avg_time = mean(times)
        all_times.extend(times)

        if fastest_overall is None or fastest_time < fastest_overall:
            fastest_overall = fastest_time
            fastest_driver = driver

        # Retrieve driver details if available
        name = driver_details.get(driver, {}).get("name", "Unknown")
        team = driver_details.get(driver, {}).get("team", "Unknown")
        
        driver_stats.append([driver, name, team, f"{fastest_time:.3f}", f"{avg_time:.3f}"])

    # Sort the stats by fastest time
    driver_stats.sort(key=lambda x: float(x[3]))

    # Display results
    print(f"\n--- {race_location} Grand Prix Timings Board ---\n")
    
    print(f"Fastest Driver: {fastest_driver} ({fastest_overall:.3f}s)\n")

    print("Driver Performance:")
    headers = ["Code", "Name", "Team", "Fastest Time (s)", "Average Time (s)"]
    print(tabulate(driver_stats, headers=headers, tablefmt="grid"))

    overall_avg_time = mean(all_times)
    print(f"\nOverall Average Time: {overall_avg_time:.3f}s")

if __name__ == "__main__":
    # Check if a file path is provided as a command-line argument
    if len(sys.argv) != 2:
        print(f"Usage: python {sys.argv[0]} <lap_times_file>")
    else:
        process_lap_times(sys.argv[1])



#     python timings_board.py lap_times_1.txt